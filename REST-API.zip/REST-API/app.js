// import express
const express = require("express");
const { listen } = require("express/lib/application");

// membuat objek express
const app = express();

// definisi port
app.listen(3000);

// import router
const router = require("./routes/api");   

const router = import("./routes/api");

// memasang router
app.use(router);