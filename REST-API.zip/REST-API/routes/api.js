// import express
const express = require("express");

// object router
const router = express.Router();

router.get("/", function ( req, res) {
    res.send("Hello Express !");
});

// Routing untuk students
router.get("/students", function (req, res) {
    res.send("Menampilkan data students");
});

router.post("/students", function (req, res) {
    res.send("Menambahkan data students");
});

router.put("/students/:id", function (req, res) {
    res.send("Mengedit data students" + req.params.id);
});

router.delete("/students/:id", function (req, res) {
    res.send("Menghapus data students" + req.params.id);
});

// export
export default router;